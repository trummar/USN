# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 01:53:00 2022

@author: vande
"""

from tilfeldig import tilfeldigheltall

tall = tilfeldigheltall(1,6)

print(tall)




