# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 01:53:00 2022

@author: vande
"""

import random as rd

tall = rd.randint(1,6)

print(tall)




