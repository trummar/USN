# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 17:30:11 2022

@author: vande
"""


import random as rd


for i in range(21):

    tall = rd.randint(1,2)
    
    if tall == 1:
        print("mynt")
        
    elif tall == 2:
        print("kron")
    
    else:
        print("Noko er gale")







