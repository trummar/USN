# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 17:30:11 2022

@author: vande
"""


import random as rd

liste_valg = ["mynt","kron"]

tall = rd.choice(liste_valg)
print(tall)





