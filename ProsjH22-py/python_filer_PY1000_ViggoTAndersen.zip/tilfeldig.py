# -*- coding: utf-8 -*-
"""
Created on Fri Dec  9 16:59:26 2022

@author: vande
"""

from random import randint

def tilfeldigheltall(start, stopp):
    tall = randint(start, stopp)
    return tall
    


